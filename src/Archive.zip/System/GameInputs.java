package System;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Steffen
 */

import GUI.FrameGUI;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class GameInputs {
    
    
    private JTextArea textarea;
    private JScrollPane textareascrollpane;
    
    
    
    
 public GameInputs()
 {
     
 }
 
 
 public JTextField createTextField()
 {
        JTextField textfield = new JTextField();
        textfield.setText(">");
        
        textfield.setPreferredSize( new Dimension( 770, 34 ) );
                
        textfield.addKeyListener(new KeyAdapter()
        {
        public void keyPressed(KeyEvent e)
        {
        if (e.getKeyCode() == KeyEvent.VK_ENTER)
        {
          String input = textfield.getText();
          
          
          textarea.append(input + "\n");
          
          textarea.setCaretPosition(textarea.getDocument().getLength());

          
          

        }
        
        }
    });
        
        
        
        
        
        return textfield;     
 }
 
 public JTextArea createTextArea()
 {
   
        
        textarea = new JTextArea(41,64);
        
        textarea.setLineWrap(true);
        
        
        //textarea.setText("Test");
        
        //textarea.setEditable(false);
       
        return textarea;
 }
 
 
 public void walkNorth()
 {
     createTextArea().append("walk north");
 }
 
 
 
 
 
 
 
 
 
 
 
 
}
