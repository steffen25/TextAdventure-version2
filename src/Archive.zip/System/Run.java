package System;


import GUI.FrameGUI;



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Steffen
 */
public class Run {
    
    public static void main(String[] args)
    {  
        FrameGUI game1 = new FrameGUI();
        game1.setVisible(true);
    }
}
